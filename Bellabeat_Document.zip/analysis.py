"""
Bellabeat smart-device usage analysis.
Requires dailyActivity_merged.csv and dailyCalories_merged.csv in this folder.
Run: python analysis.py
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data" if (ROOT / "data" / "dailyActivity_merged.csv").exists() else ROOT
activity = pd.read_csv(DATA_DIR / "dailyActivity_merged.csv")
calories = pd.read_csv(DATA_DIR / "dailyCalories_merged.csv")

activity["Date"] = pd.to_datetime(activity["ActivityDate"], format="%m/%d/%Y", errors="coerce")
calories["Date"] = pd.to_datetime(calories["ActivityDay"], format="%m/%d/%Y", errors="coerce")
activity["Weekday"] = activity["Date"].dt.day_name()
activity["DayType"] = np.where(activity["Date"].dt.dayofweek >= 5, "Weekend", "Weekday")
activity["StepBand"] = pd.cut(
    activity["TotalSteps"], [-1, 4999, 7499, 9999, np.inf],
    labels=["Under 5,000", "5,000–7,499", "7,500–9,999", "10,000+"]
)

matched = activity[["Id", "Date", "Calories"]].merge(
    calories[["Id", "Date", "Calories"]],
    on=["Id", "Date"], how="outer", suffixes=("_activity", "_calories"), indicator=True
)
print("Daily calorie file matches activity file:", bool(
    (matched["_merge"] == "both").all()
    and (matched["Calories_activity"] == matched["Calories_calories"]).all()
))
print("Rows:", len(activity))
print("Unique participants:", activity["Id"].nunique())
print("Date range:", activity["Date"].min().date(), "to", activity["Date"].max().date())
print("Duplicate participant-date keys:", activity.duplicated(["Id", "Date"]).sum())
print("Missing cells:", activity.isna().sum().sum())
print(activity[["TotalSteps", "TotalDistance", "Calories", "SedentaryMinutes",
                "LightlyActiveMinutes", "FairlyActiveMinutes", "VeryActiveMinutes"]].describe().round(2))

print("\\nPearson correlations:")
print("Steps vs calories:", round(activity["TotalSteps"].corr(activity["Calories"]), 3))
print("Steps vs sedentary minutes:", round(activity["TotalSteps"].corr(activity["SedentaryMinutes"]), 3))

weekday = activity.groupby("Weekday").agg(
    records=("Id", "size"), avg_steps=("TotalSteps", "mean"),
    avg_sedentary=("SedentaryMinutes", "mean"), avg_calories=("Calories", "mean")
).reindex(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
weekday.to_csv(ROOT / "weekday_summary.csv")
activity.groupby("DayType").agg(
    records=("Id", "size"), avg_steps=("TotalSteps", "mean"),
    avg_sedentary=("SedentaryMinutes", "mean"), avg_calories=("Calories", "mean")
).to_csv(ROOT / "weekday_weekend_summary.csv")
bands = activity["StepBand"].value_counts(sort=False)
pd.DataFrame({"step_band": [str(x) for x in bands.index],
              "daily_records": bands.values,
              "share_percent": bands.values / len(activity) * 100}).to_csv(
                  ROOT / "step_band_summary.csv", index=False)

chart_dir = ROOT / "charts"
chart_dir.mkdir(exist_ok=True)
plt.figure(figsize=(9.5, 5.2))
plt.bar(weekday.index, weekday["avg_steps"])
plt.axhline(activity["TotalSteps"].mean(), linestyle="--", linewidth=1.4,
            label=f"Overall mean: {activity['TotalSteps'].mean():,.0f}")
plt.title("Average daily steps by day of week")
plt.ylabel("Average steps")
plt.xticks(rotation=25, ha="right")
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(chart_dir / "average_steps_by_weekday.png", dpi=180, bbox_inches="tight")
plt.close()

plt.figure(figsize=(8.8, 5.3))
plt.scatter(activity["TotalSteps"], activity["Calories"], alpha=0.5)
slope, intercept = np.polyfit(activity["TotalSteps"], activity["Calories"], 1)
xx = np.linspace(activity["TotalSteps"].min(), activity["TotalSteps"].max(), 100)
plt.plot(xx, slope * xx + intercept, linewidth=2)
plt.title(f"Daily steps and calories (r = {activity['TotalSteps'].corr(activity['Calories']):.2f})")
plt.xlabel("Total steps per day")
plt.ylabel("Calories recorded per day")
plt.tight_layout()
plt.savefig(chart_dir / "steps_vs_calories.png", dpi=180, bbox_inches="tight")
plt.close()

plt.figure(figsize=(8.8, 5.3))
plt.scatter(activity["TotalSteps"], activity["SedentaryMinutes"], alpha=0.45)
slope, intercept = np.polyfit(activity["TotalSteps"], activity["SedentaryMinutes"], 1)
plt.plot(xx, slope * xx + intercept, linewidth=2)
plt.title(f"Daily steps and sedentary minutes (r = {activity['TotalSteps'].corr(activity['SedentaryMinutes']):.2f})")
plt.xlabel("Total steps per day")
plt.ylabel("Sedentary minutes per day")
plt.tight_layout()
plt.savefig(chart_dir / "steps_vs_sedentary_minutes.png", dpi=180, bbox_inches="tight")
plt.close()

plt.figure(figsize=(8.8, 5.0))
plt.bar([str(x) for x in bands.index], bands.values)
plt.title("Distribution of daily step totals")
plt.ylabel("Daily records")
plt.xlabel("Step-count band (descriptive categories)")
for i, v in enumerate(bands.values):
    plt.text(i, v + 5, f"{v} ({v/len(activity)*100:.1f}%)", ha="center", fontsize=9)
plt.tight_layout()
plt.savefig(chart_dir / "daily_step_bands.png", dpi=180, bbox_inches="tight")
plt.close()
print("\\nTables and charts saved.")
