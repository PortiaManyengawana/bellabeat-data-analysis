# Bellabeat Smart Device Usage Analysis

A portfolio case study based on the Google Data Analytics Bellabeat capstone brief. The project uses the Fitbit Fitness Tracker dataset to explore activity patterns and translate them into testable product and marketing recommendations for the **Bellabeat app**.

## Business task

Analyze daily smart-device usage patterns to answer:
1. What trends appear in the activity data?
2. How might these trends be relevant to Bellabeat customers?
3. How could Bellabeat use the findings to inform product engagement and marketing?

## Dataset and scope

- **Source:** [Fitbit Fitness Tracker Data on Kaggle](https://www.kaggle.com/arashnic/fitbit)
- **Files analysed:** `dailyActivity_merged.csv` and `dailyCalories_merged.csv`
- **Observed activity table:** 940 user-day records from 33 unique participant IDs, covering 12 Apr 2016 to 12 May 2016.
- **Important scope limitation:** The sleep CSV (`sleepDay_merged.csv`) was not supplied for this analysis, so no sleep findings or sleep-related correlations are claimed. The activity dataset includes no demographic fields, so demographic segmentation is not possible.
- The dataset is historical and small; it should be treated as directional rather than representative of today's broader market or Bellabeat's own customers.

## Key findings

- Mean daily steps across recorded user-days: **7,638** (median 7,406; range 0–36,019).
- Mean daily distance: **5.49** distance units as recorded in the source (the dataset labels the field `TotalDistance`; the unit should be confirmed against source documentation before communicating externally).
- Mean recorded calories: **2,304** per user-day.
- Average sedentary time: **991 minutes** per recorded user-day. This is a tracker field, not a confirmed measure of waking time for every record.
- Daily steps and recorded calories have a **moderate positive Pearson correlation** (r = 0.59; r² = 0.35). This is association, not causation; calories also reflect individual differences and device estimates.
- Daily steps and sedentary minutes have a **weak-to-moderate negative correlation** (r = -0.33; r² = 0.11). The relationship explains only a limited share of variation and does not establish that one causes the other.
- Tuesday has the highest mean daily steps in this sample (**8,125**); Sunday has the lowest (**6,933**). These are descriptive results for this small, historical sample, not universal behaviour.
- **32.2%** of daily records fall below 5,000 steps, while **32.2%** have 10,000 or more. These are simple descriptive bins chosen for this analysis, not clinical classifications.

## Data preparation and quality checks

1. Parsed `ActivityDate` and `ActivityDay` using the source's month/day/year format.
2. Checked the activity data for missing cells, repeated participant-date keys, zero-step days and zero-calorie days.
3. Compared the two supplied files by participant and date. The daily calorie file matches the `Calories` field in the activity file across all matched records, so it was not double-counted as an independent source.
4. Kept zero-step records in the descriptive results but flagged them as a data-quality caveat rather than assuming they are valid inactivity days or deleting them without a documented rule.
5. Derived weekday, weekday/weekend, and descriptive step-band fields for comparisons.

### Data quality summary

- Missing cells in the raw activity table: **0**
- Duplicate participant-date keys: **0**
- Records with zero steps: **77**
- Records with zero calories: **4**
- Records with 1,440 sedentary minutes: **79**
- Records with both zero steps and 1,440 sedentary minutes: **72**
- `dailyCalories_merged.csv` agrees with the activity file's calorie values on all matched participant-date records: **True**

## Recommendations

### 1. Test supportive movement prompts
Offer optional, user-controlled prompts to break up long inactive periods. Test timing and message tone rather than assuming every user wants reminders. Measure reminder opt-in, follow-through and notification opt-outs.

### 2. Make progress visible and personal
Provide weekly summaries that highlight personal activity trends and achievable next steps. Test weekly active use, summary opens and retention; avoid comparing users against a single ideal profile.

### 3. Use day-of-week patterns as a campaign hypothesis
The observed Tuesday/Sunday difference suggests testing whether weekday-specific prompts or weekend planning content are useful. Validate the pattern with more recent and larger datasets before scaling a campaign.

## Limitations

- Only two related daily-level CSVs were analysed; the calories file duplicates a field already present in daily activity.
- Sleep, heart rate, hourly activity, hydration, stress and Bellabeat product usage were not analysed.
- The source covers a short period in 2016 and has no demographic information.
- Some zero-step and zero-calorie records may reflect non-wear, incomplete tracking or other data issues; they were not silently removed.
- Pearson correlations describe linear association only and are sensitive to unusual values. They do not establish causal effects.
- Results from Fitbit users are proxies for possible market behaviours, not evidence about Bellabeat customers.

## Reproduce the analysis

Install the packages below. In the supplied ZIP, the two source CSV files are in the `data/` folder; the script also supports placing them beside `analysis.py`. Then run from the project folder:

```bash
pip install pandas numpy matplotlib
python analysis.py
```

The script prints summary statistics and saves analysis tables and charts. The report PDF is included as a portfolio-ready summary.

## Files

- `Bellabeat_Final_Case_Study.pdf` — written report
- `analysis.py` — reproducible analysis script
- `weekday_summary.csv` — weekday-level summary
- `weekday_weekend_summary.csv` — weekday/weekend comparison
- `step_band_summary.csv` — daily step-band distribution
- `charts/` — generated visualizations
- `data/` — the two CSV files used for this analysis

## Framework

The report follows the Google Data Analytics process: **Ask, Prepare, Process, Analyze, Share, Act**.

## Source

Fitbit Fitness Tracker Data (Möbius), Kaggle: https://www.kaggle.com/arashnic/fitbit  
Case study prompt: Google Data Analytics Professional Certificate, Bellabeat case study, “How can a wellness company play it smart?”
